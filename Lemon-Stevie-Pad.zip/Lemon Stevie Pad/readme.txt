Lemon-Stevie-Pad
################

Lemon-Stevie-Pad is an AutoHotkey scripted customisable graphical keypad.



How to use Lemon-Stevie-Pad
###########################

1. Download and install AutoHotkey https://www.autohotkey.com/

2. Set the [Keypad_Size] in the settings.ini.

3. Run Lemon Stevie Pad.ahk

4. To show or hide the keypad press the "middle mouse button" and scroll the mouse wheel up and down, edit the hotkeys to       your own prefernce in the settings .ini.

5. To position the the keypad hold Shift+X and drag the window the coordinates will be saved in settings.ini.



Customise
#########

-Customise the settings of Lemon-Stevie-Pad in the settings.ini.

-Customise the key inputs of each button in the settings.ini.

-Customise the key pad button graphics, by editing the .png files.

-Customise the audio of each button.



List of Keys
############

https://www.autohotkey.com/docs/KeyList.htm


Input_up option
###############

For Key combinations such as "LShift + 1" use the input [Input_up] option.

example
------------------------
[Input_1]                     
{LShift down}{1 down}          
[Input_1_up]   
{LShift up}{1 up}     
------------------------




Disclaimer
##########
Use at your own risk.  

      

Thanks for downloading Lemon-Stevie-Pad.


